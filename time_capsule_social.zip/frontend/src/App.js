import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [message, setMessage] = useState("");
  const [recipient, setRecipient] = useState("");
  const [date, setDate] = useState("");

  const handleSubmit = async () => {
    const res = await axios.post("http://localhost:8000/capsule", {
      message,
      recipient,
      unlock_date: date
    });
    alert("Capsule Created: " + res.data.capsule_id);
  };

  return (
    <div>
      <h1>Time Capsule</h1>
      <input placeholder="Recipient" onChange={e => setRecipient(e.target.value)} />
      <textarea placeholder="Message" onChange={e => setMessage(e.target.value)} />
      <input type="date" onChange={e => setDate(e.target.value)} />
      <button onClick={handleSubmit}>Create Capsule</button>
    </div>
  );
}

export default App;
