import json

def schedule_capsule(data, capsule_id):
    with open(f"capsules/{capsule_id}.json", "w") as f:
        json.dump(data, f)
    return True
