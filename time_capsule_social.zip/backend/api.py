from fastapi import FastAPI
from pydantic import BaseModel
from scheduler import schedule_capsule
from blockchain import store_on_chain

app = FastAPI()

class Capsule(BaseModel):
    recipient: str
    message: str
    unlock_date: str

@app.post("/capsule/")
def create_capsule(capsule: Capsule):
    capsule_id = store_on_chain(capsule.dict())
    schedule_capsule(capsule.dict(), capsule_id)
    return {"status": "Scheduled", "capsule_id": capsule_id}
