import hashlib
from datetime import datetime

def store_on_chain(data):
    raw = str(data) + str(datetime.utcnow())
    return hashlib.sha256(raw.encode()).hexdigest()
