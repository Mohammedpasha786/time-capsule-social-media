# ⏳ Time Capsule Social Media

## 🧠 About

This project is based on a patented system that allows users to create digital time capsules — storing and scheduling personal messages, media, and experiences to be unlocked in the future.

### Patent Info:
- Patent Application No: 20254104949 A
- Title: Time Capsule Social Media
- Filed: 15/05/2025 | Published: 30/05/2025

## 🔐 Features

- Schedule content to be unlocked at future date
- Blockchain for authenticity and tamper-proof storage
- React frontend for user-friendly interaction
- Solidity smart contract for secure handling
- FastAPI backend for scheduling and capsule logic

## 🚀 Getting Started

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn api:app --reload
```

### Frontend

```bash
cd frontend
npm install
npm start
```

## 🧱 Smart Contract Deployment

```bash
cd smart_contract
# Use Remix IDE or Hardhat to deploy
```

## 🛡 Security & Privacy

This system includes:
- Blockchain-backed record integrity
- Access control using unlock dates
- Future expansion: wallet-based recipient validation

## 🤝 Collaboration

Made by Afreed Pasha and team @ SR University.  
For demo access or licensing queries, contact afreed@example.com
